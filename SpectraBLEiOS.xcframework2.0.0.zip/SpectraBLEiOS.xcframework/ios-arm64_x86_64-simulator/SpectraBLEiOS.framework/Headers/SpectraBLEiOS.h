//
//  SpectraBLEiOS.h
//  SpectraBLEiOS
//
//  Created by Spectra-iOS on 31/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SpectraBLEiOS.
FOUNDATION_EXPORT double SpectraBLEiOSVersionNumber;

//! Project version string for SpectraBLEiOS.
FOUNDATION_EXPORT const unsigned char SpectraBLEiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SpectraBLEiOS/PublicHeader.h>


